import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import urllib2,urllib
import re
import downloader
from BeautifulSoup import BeautifulSoup as bs

AddonID ='plugin.image.easywallpapers'
selfAddon = xbmcaddon.Addon(id=AddonID)
addon_handle = int(sys.argv[1])
ADDON_DATA   =  xbmc.translatePath(os.path.join('special://','home'))
ADDON=xbmcaddon.Addon(id='plugin.image.easywallpapers')
dialog = xbmcgui.Dialog()    
FANARTICO = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID, 'icon.png'))
backupdir	=	unicode(selfAddon.getSetting('remote_path'))   
download_dir     =  xbmc.translatePath(os.path.join(backupdir,''))
dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()

def SETTINGS():
	xbmcaddon.Addon(id='plugin.image.easywallpapers').openSettings()
def CATEGORIES():
	addDir('[COLOR yellow][B]Use Right Click and download item to save Images[/B][/COLOR]','url',1,icon,FANARTICO,'')
	try:
		if not os.path.exists(download_dir): os.makedirs(download_dir)
	except:pass
	addDir2('[B]BhmPics[/B]','http://www.bhmpics.com/',4,icon,FANARTICO)
	addDir2('[B]Wallpapers Wide[/B]','http://wallpaperswide.com/',2,icon,FANARTICO)
	addDir2('[B]HD Wallpapers[/B]','http://www.hdwallpapers.in/',3,icon,FANARTICO)	
	
	
	
	
def Download_wallpapers(name,url):
	try:
		if not os.path.exists(download_dir): os.makedirs(download_dir)
	except:pass
	import datetime
	name = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
	name = "wallpaper_" + name + ".jpg"
	path = download_dir
	dp = xbmcgui.DialogProgress()
	lib=os.path.join(path, name)
	dp.create("Ez Wallpaper","Downloading ",'', 'Please Wait')		
	downloader.download(url, lib, dp)
	dialog.ok('Easy wallpers','Download completed...')
############ BHM PICS ##############	
def Bhmpics_list(name,url):
	addDir2('[B]Search >>>[/B]','url',43,icon,FANARTICO)	
	link = OPEN_URL(url)
	soup=bs(link)
	tag=soup.find('ul',{'class':'side-panel categories'})
	match=re.compile('href="(.+?)">(.+?)</a>', re.DOTALL).findall(str(tag))
	for url, name in match:
		name = name.replace('&amp;','&')
		url = "http://www.bhmpics.com%s" % url
		addDir('[B]'+name+'[/B]',url,41,icon,FANARTICO,'')	
def Bhmpics_content(name,url):
	link = OPEN_URL(url)
	for item in parse_dom(link, 'div', {'class': 'thumb'}):
		matchlink = re.compile('<a href="(.+?)">').findall(item)
		matchimg = 	re.compile('<img src="(.+?)" alt="(.+?)"').findall(item)
		for url in matchlink:
			url = "http://www.bhmpics.com%s" % url
			for img,name in matchimg:
				img = "http://www.bhmpics.com%s" % img
				addDir(name,url,42,img,img,'')		
	for nextpage in parse_dom(link, 'div', {'class': 'pagination'}):
		match = re.compile('<a href="(.+?)">(\d+)</a>').findall(nextpage)
		for url,pageid in match:
			url = "http://www.bhmpics.com/%s" % url
			addDir('Page ' + pageid + " >>>",url,41,icon,FANARTICO,'')	
def Bhmpics_quality(name,url,iconimage):
	link = OPEN_URL(url)
	img = iconimage
	match = re.compile('<a target="_blank" href="(.+?)" title=".+?">(.+?)</a>').findall(link)
	for url,name in match:
		url = "http://www.bhmpics.com%s" % url
		redirect = OPEN_URL(url)
		matchredirect = re.compile('<a href="(.+?)" style=".+?">Download</a>').findall(redirect)[:-1]
		for url in matchredirect:
			url = "http://www.bhmpics.com%s" % url
			liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
			liz.setInfo( type="Image", infoLabels={ "Title": name } )
			liz.setProperty('fanart_image', img)		
			cm = []
			cm.append(('[COLOR red]Download Item[/COLOR]', 'RunPlugin(%s?mode=100&name=%s&url=%s&)'%(sys.argv[0],name,url)))
			liz.addContextMenuItems(cm, replaceItems=False)
			xbmcplugin.addDirectoryItem(addon_handle, url, liz, False)	
############ HD WALLPAPERS ##############	
def Hdwallpapers_list(name,url):
	addDir2('[B]Search >>>[/B]','url',33,icon,FANARTICO)	
	link = OPEN_URL(url)
	soup=bs(link)
	tag=soup.find('ul',{'class':'side-panel categories'})
	match=re.compile('href="(.+?)">(.+?)</a>', re.DOTALL).findall(str(tag))
	for url, name in match:
		name = name.replace('&amp;','&')
		url = "http://www.hdwallpapers.in/%s" % url
		addDir('[B]'+name+'[/B]',url,31,icon,FANARTICO,'')
def Hdwallpapers_content(name,url):
	link = OPEN_URL(url)
	match=re.compile('<div class="thumb"><a href="(.+?)"><p>(.+?)</p><img src="(.+?)"').findall(link)
	for url, name, img in match:
		url = "http://www.hdwallpapers.in/%s" % url
		img = "http://www.hdwallpapers.in/%s" % img
		addDir(name,url,32,img,img,'')		
	for nextpage in parse_dom(link, 'div', {'class': 'pagination'}):
		match = re.compile('<a href="(.+?)">(\d+)</a>').findall(nextpage)
		for url,pageid in match:
			url = "http://www.hdwallpapers.in/%s" % url
			addDir('Page ' + pageid + " >>>",url,31,icon,FANARTICO,'')
def Hdwallpapers_quality(name,url,iconimage):
	link = OPEN_URL(url)
	img = iconimage
	for items in parse_dom(link, 'div', {'class': 'wallpaper-resolutions'}):
		match = re.compile('<a href="(.+?)" title=".+?">(.+?)</a>').findall(items)
		for url,name in match:
			url = "http://www.hdwallpapers.in/%s" % url
			liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
			liz.setInfo( type="Image", infoLabels={ "Title": name } )
			liz.setProperty('fanart_image', img)		
			cm = []
			cm.append(('Download Item', 'RunPlugin(%s?mode=100&name=%s&url=%s&)'%(sys.argv[0],name,url)))
			liz.addContextMenuItems(cm, replaceItems=False)		
			xbmcplugin.addDirectoryItem(addon_handle, url, liz, False)
############ WALLPAPER WIDE ##############			
def Wallpapers_wide(name,url):
	addDir2('[B]Search >>>[/B]','url',23,icon,FANARTICO)	
	link = OPEN_URL(url)
	soup=bs(link)
	tag=soup.find('ul',{'class':'side-panel categories'})
	match=re.compile('<a href="(.+?)" title=".+?">(.+?)</a>').findall(str(tag))
	for url, name in match:
		url = "http://wallpaperswide.com%s" % url
		addDir('[B]'+name+'[/B]',url,21,icon,FANARTICO,'')
		
def Wallpapers_wide_content(name,url,description):
	link = OPEN_URL(url)
	for item in parse_dom(link, 'div', {'class': 'thumb'}):
		match = re.compile('<a href="(.+?)" title="(.+?)" itemprop=".+?">').findall(item)
		match2 = re.compile('<img src="(.+?)"').findall(item)
		for img in match2:
				for url, name in match:
					url = "http://wallpaperswide.com%s" % url
					addDir(name,url,22,img,img,'')
	for nextpage in parse_dom(link, 'div', {'class': 'pagination'}):
		match = re.compile('<a href="(.+?)">(\d+)</a>').findall(nextpage)
		for url,pageid in match:
			url = "http://wallpaperswide.com%s" % url
			addDir('Page ' + pageid + " >>>",url,21,icon,FANARTICO,'')				
def Wallpapers_wide_quality(name,url,iconimage):
	link = OPEN_URL(url)
	img = iconimage
	match = re.compile('<a target="_self" href="(.+?)" title=".+?">(.+?)</a>').findall(link)
	for url,name in match:
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Image", infoLabels={ "Title": name } )
		url = "http://wallpaperswide.com%s" % url
		liz.setProperty('fanart_image', img)		
		cm = []
		cm.append(('Download Item', 'RunPlugin(%s?mode=100&name=%s&url=%s&)'%(sys.argv[0],name,url)))
		liz.addContextMenuItems(cm, replaceItems=False)		
		xbmcplugin.addDirectoryItem(addon_handle, url, liz, False)


		
############ SEARCH ##############		
def SEARCH_Wallpaperwide(url):
	search_entered =''
	keyboard = xbmc.Keyboard(search_entered, 'Search')
	keyboard.doModal()
	if keyboard.isConfirmed(): search_entered = keyboard.getText()
	if len(search_entered)>1:
		search_entered = search_entered.replace(' ','%20')
		search_link = 'http://wallpaperswide.com/search.html?q=%s' % search_entered
		name = ''
		iconimage = ''
		Wallpapers_wide_content(name,search_link,iconimage)
def SEARCH_Hdwallpapers(url):
	search_entered =''
	keyboard = xbmc.Keyboard(search_entered, 'Search')
	keyboard.doModal()
	if keyboard.isConfirmed(): search_entered = keyboard.getText()
	if len(search_entered)>1:
		search_entered = search_entered.replace(' ','%20')
		search_link = 'http://www.hdwallpapers.in/search.html?q=%s' % search_entered
		name = ''
		iconimage = ''
		Hdwallpapers_content(name,search_link)
def SEARCH_Bhmpics(url):
	search_entered =''
	keyboard = xbmc.Keyboard(search_entered, 'Search')
	keyboard.doModal()
	if keyboard.isConfirmed(): search_entered = keyboard.getText()
	if len(search_entered)>1:
		search_entered = search_entered.replace(' ','%20')
		search_link = 'http://www.bhmpics.com/search.html?q=%s' % search_entered
		name = ''
		iconimage = ''
		Bhmpics_content(name,search_link)	

		
def OPEN_URL(url):
        hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
			   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			   'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
			   'Accept-Encoding': 'none',
			   'Accept-Language': 'en-US,en;q=0.8',
			   'Connection': 'keep-alive'}
        req = urllib2.Request(url, headers=hdr)	
        # limit = int(scrapetimeout)
        response = urllib2.urlopen(req, timeout=30)
        link=response.read()
        response.close()
        return link
		
def OPEN_URL2(url):
    
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link			

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="image", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir2(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok       
       
def _getDOMContent(html, name, match, ret):
    end_str = "</%s" % (name)
    start_str = '<%s' % (name)

    start = html.find(match)
    end = html.find(end_str, start)
    pos = html.find(start_str, start + 1)

    while pos < end and pos != -1:  # Ignore too early </endstr> return
        tend = html.find(end_str, end + len(end_str))
        if tend != -1:
            end = tend
        pos = html.find(start_str, pos + 1)

    if start == -1 and end == -1:
        result = ''
    elif start > -1 and end > -1:
        result = html[start + len(match):end]
    elif end > -1:
        result = html[:end]
    elif start > -1:
        result = html[start + len(match):]
    else:
        result = ''

    if ret:
        endstr = html[end:html.find(">", html.find(end_str)) + 1]
        result = match + result + endstr

    return result

def _getDOMAttributes(match, name, ret):
    pattern = '''<%s[^>]* %s\s*=\s*(?:(['"])(.*?)\\1|([^'"].*?)(?:>|\s))''' % (name, ret)
    results = re.findall(pattern, match, re.I | re.M | re.S)
    return [result[1] if result[1] else result[2] for result in results]

def _getDOMElements(item, name, attrs):
    if not attrs:
        pattern = '(<%s(?: [^>]*>|/?>))' % (name)
        this_list = re.findall(pattern, item, re.M | re.S | re.I)
    else:
        last_list = None
        for key in attrs:
            pattern = '''(<%s [^>]*%s=['"]%s['"][^>]*>)''' % (name, key, attrs[key])
            this_list = re.findall(pattern, item, re.M | re. S | re.I)
            if not this_list and ' ' not in attrs[key]:
                pattern = '''(<%s [^>]*%s=%s[^>]*>)''' % (name, key, attrs[key])
                this_list = re.findall(pattern, item, re.M | re. S | re.I)
    
            if last_list is None:
                last_list = this_list
            else:
                last_list = [item for item in this_list if item in last_list]
        this_list = last_list
    
    return this_list

def parse_dom(html, name='', attrs=None, ret=False):
    if attrs is None: attrs = {}
    if isinstance(html, str):
        try:
            html = [html.decode("utf-8")]  # Replace with chardet thingy
        except:
            print "none"
            try:
                html = [html.decode("utf-8", "replace")]
            except:
                
                html = [html]
    elif isinstance(html, unicode):
        html = [html]
    elif not isinstance(html, list):
        
        return ''

    if not name.strip():
        
        return ''
    
    if not isinstance(attrs, dict):
        
        return ''

    ret_lst = []
    for item in html:
        for match in re.findall('(<[^>]*\n[^>]*>)', item):
            item = item.replace(match, match.replace('\n', ' ').replace('\r', ' '))

        lst = _getDOMElements(item, name, attrs)

        if isinstance(ret, str):
            lst2 = []
            for match in lst:
                lst2 += _getDOMAttributes(match, name, ret)
            lst = lst2
        else:
            lst2 = []
            for match in lst:
                temp = _getDOMContent(item, name, match, ret).strip()
                item = item[item.find(temp, item.find(match)):]
                lst2.append(temp)
            lst = lst2
        ret_lst += lst

    # log_utils.log("Done: " + repr(ret_lst), xbmc.LOGDEBUG)
    return ret_lst        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=int(params["description"])
except:
        pass
        
        

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
        
        
if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==2:
        Wallpapers_wide(name,url)
elif mode==21:
        Wallpapers_wide_content(name,url,description)       
elif mode==22:
        Wallpapers_wide_quality(name,url,iconimage)
elif mode==23:
        SEARCH_Wallpaperwide(url)
elif mode==3:
        Hdwallpapers_list(name,url)
		
elif mode==31:
		Hdwallpapers_content(name,url)
elif mode==32:
		Hdwallpapers_quality(name,url,iconimage)
elif mode==33:
		SEARCH_Hdwallpapers(url)
				
elif mode==4:
        Bhmpics_list(name,url)
elif mode==41:
		Bhmpics_content(name,url)
elif mode==42:
		Bhmpics_quality(name,url,iconimage)	
elif mode==43:
		SEARCH_Bhmpics(url)		
elif mode==100:
        Download_wallpapers(name,url)	
		
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))

